#!/usr/bin/python -3
# -*- coding: UTF-8 -*-
import time; import os; import scr   #scr my module for work with screen
try:                                   
  with open('timer.ini', 'r') as f:   
	line = f.readline(); f.close()       # read first row 
except: 
	scr.errShow("Error: opening or reading the file timer.ini"); quit()
s=''; p=line.split(";");           # select in first row 'min' (first number) and 'step' (second number)
min=int(p[0]); step=int(p[1])   # interval (min) and step(sec) from first row[nums[0]] file limit.ini
while (1):
	os.system('clear')                  # clear the screen
	if(s!=''):  scr.errShow("ERROR: You have entered '" +s+"' Must be a number > 0")
	scr.setxy(2,0);                     # set cursor in 2 row 0 column
	print "Step is %d second(s)\n\n" %(step)
	print "Enter interval in minut(s): \n%d" %min;   print "\033[2A"
	s=raw_input(); w=0; m=min
	if (s != ''): 	
	  try:   m=int(s)
	  except:  w=1
	  if(w==1 or m < 1 ): continue
	min=m
	scr.errShow('')
	for i in range(0, min):
	  for j in range(0,60,step):
		scr.title(str(i)+':'+str(j)+' ['+str(min)+'m]')
		scr.setxy(6,0);  time.sleep(step)                    # delay in sekunds; sleep(1) = 1 second
	scr.title(str(min)+' ['+str(min)+'m]')
	os.system(p[2])                                   # execute command from second row file limit.ini
	j=i; s=''