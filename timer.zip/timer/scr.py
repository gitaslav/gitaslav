# Title from (s)
def title(s):  print "\033]0;%s\007" %(s)
# set cursor. x-line,y-column      
def setxy(x,y): print "\033[%s;%sf" %(x,y)     
# store x,y; cursor in 0,0; clear line; set color RED; print message(%s); restore x,y; 2 lines up; set black color; get x,y
def errShow(s): print "\033[s\033[H\033[K\033[1;31m%s\033[u\033[2A\033[1;30m\033[6D" %s